package com.managedCare.salesOperation.enquiry.Response;

import org.springframework.stereotype.Component;

import lombok.Data;
@Component
@Data
public class ActivityOfDailyLiving {
	
	private String title;
	private String value;

}
