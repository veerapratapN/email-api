package com.managedCare.salesOperation.enquiry.Response;

public class EnquiryDTO {

}
