package com.managedCare.salesOperation.enquiry.Response;


import lombok.Data;

@Data
public class Status {
	
	
	private String label;
	private Integer count;

}
