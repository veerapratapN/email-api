package com.managedCare.salesOperation.enquiry.Constatnt;

public interface CommonConstant {
	
	public static final String OPEN = "open";

}
